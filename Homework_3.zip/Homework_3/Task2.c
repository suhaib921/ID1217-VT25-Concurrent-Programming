#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdint.h>
#include <time.h>

#define SHARED 1

/* Global Variables */
sem_t potSem;          // Counting semaphore for honey portions
sem_t bearSem;         // Signals bear when pot is full
sem_t mutex;           // Mutex for shared variables
int H;                 // Pot capacity
int nHoneybees;        // Number of honeybees
int honeyInPot = 0;    // Current honey in pot
int maxIterations = 5; // Maximum refill cycles
int currentIteration = 0;
int** contributions;   // Dynamic array for contributions
int simulationRunning = 1;

/* Bear Thread */
void *bear(void *arg) {
    while (simulationRunning) {
        sem_wait(&bearSem); // Wait for pot to be full

        sem_wait(&mutex);
        if (!simulationRunning) {
            sem_post(&mutex);
            break;
        }

        printf("\nBear: Pot is full! Eating %d portions...\n", H);
        honeyInPot = 0;
        currentIteration++;

        // Print contributions for previous iteration
        printf("\n=== Iteration %d Contributions ===\n", currentIteration);
        for (int i = 0; i < nHoneybees; i++) {
            printf("Honeybee %d: %d portions\n", i+1, contributions[i][currentIteration-1]);
        }

        if (currentIteration >= maxIterations) {
            simulationRunning = 0;
            // Wake all honeybees to exit
            for (int i = 0; i < H; i++) sem_post(&potSem);
        }
        sem_post(&mutex);

        sleep(2); // Simulate eating
        printf("Bear: Finished eating. Going back to sleep.\n");
    }
    return NULL;
}

/* Honeybee Thread */
void *honeybee(void *arg) {
    int id = (intptr_t)arg;
    while (1) {
        sem_wait(&mutex);
        if (!simulationRunning) {
            sem_post(&mutex);
            break;
        }
        sem_post(&mutex);

        sleep((rand() % 2) + 1); // Simulate gathering time

        sem_wait(&mutex);
        if (honeyInPot < H && simulationRunning) {
            honeyInPot++;
            contributions[id][currentIteration]++;
            printf("Honeybee %d: Added 1 portion. Total: %d\n", id+1, honeyInPot);

            if (honeyInPot == H) {
                sem_post(&bearSem); // Notify bear
            }
        }
        sem_post(&mutex);
    }
    return NULL;
}

/* Main Function */
int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <honeybees> <pot_capacity>\n", argv[0]);
        return EXIT_FAILURE;
    }

    nHoneybees = atoi(argv[1]);
    H = atoi(argv[2]);
    srand(time(NULL));

    // Initialize contributions array
    contributions = malloc(nHoneybees * sizeof(int*));
    for (int i = 0; i < nHoneybees; i++) {
        contributions[i] = calloc(maxIterations, sizeof(int));
    }

    // Initialize semaphores
    sem_init(&potSem, SHARED, 0);
    sem_init(&bearSem, SHARED, 0);
    sem_init(&mutex, SHARED, 1);

    pthread_t bearThread;
    pthread_t bees[nHoneybees];

    pthread_create(&bearThread, NULL, bear, NULL);
    for (int i = 0; i < nHoneybees; i++) {
        pthread_create(&bees[i], NULL, honeybee, (void*)(intptr_t)i);
    }

    // Wait for threads
    pthread_join(bearThread, NULL);
    for (int i = 0; i < nHoneybees; i++) pthread_join(bees[i], NULL);

    // Print results
    printf("\n=== Final Results ===\n");
    for (int i = 0; i < nHoneybees; i++) {
        int total = 0;
        for (int j = 0; j < maxIterations; j++) total += contributions[i][j];
        printf("Honeybee %d: %d portions\n", i+1, total);
    }

    // Cleanup
    for (int i = 0; i < nHoneybees; i++) free(contributions[i]);
    free(contributions);
    sem_destroy(&potSem);
    sem_destroy(&bearSem);
    sem_destroy(&mutex);

    return 0;
}