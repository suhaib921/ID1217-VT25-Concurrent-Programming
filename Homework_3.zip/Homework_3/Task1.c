#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdint.h>

#define SHARED 1

/* Global Variables */
sem_t dishSem;          // Counting semaphore for worms
sem_t parentSem;        // Signals parent when dish is empty
sem_t mutex;            // Mutex for shared variables
int W;                  // Dish capacity
int nBabyBirds;         // Number of baby birds
int simulationRunning = 1;
int maxIterations = 5;
int currentIteration = 0;
int* wormsEaten;        // Dynamic array for tracking consumption

/* Parent Bird Thread */
void *parentBird(void *arg) {
    while (simulationRunning) {
        sem_wait(&parentSem); // Wait for empty dish
        
        sem_wait(&mutex);
        if (!simulationRunning) {
            sem_post(&mutex);
            break;
        }

        printf("\nParent: Refilling dish (%d/%d)\n", currentIteration + 1, maxIterations);
        sleep(1); // Simulate refill time

        // Refill the dish and wake all babies
        for (int i = 0; i < W; i++) sem_post(&dishSem);
        currentIteration++;

        if (currentIteration >= maxIterations) {
            simulationRunning = 0;
            // Wake all babies to exit
            for (int i = 0; i < nBabyBirds; i++) sem_post(&dishSem);
        }
        sem_post(&mutex);
    }
    return NULL;
}

/* Baby Bird Thread */
void *babyBird(void *arg) {
    int id = (intptr_t)arg;
    while (1) {
        sem_wait(&mutex);
        if (!simulationRunning) {
            sem_post(&mutex);
            break;
        }
        sem_post(&mutex);

        sem_wait(&dishSem); // Wait for worm
        
        sem_wait(&mutex);
        if (!simulationRunning) {
            sem_post(&dishSem);
            sem_post(&mutex);
            break;
        }

        wormsEaten[id]++;
        int wormsLeft;
        sem_getvalue(&dishSem, &wormsLeft);
        
        printf("Baby %d: Took worm. Left: %d. Total: %d\n", 
              id + 1, wormsLeft, wormsEaten[id]);
        
        if (wormsLeft == 0) {
            sem_post(&parentSem); // Notify parent
        }
        sem_post(&mutex);
        
        sleep(1); // Simulate eating
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <baby_birds> <initial_worms>\n", argv[0]);
        return EXIT_FAILURE;
    }

    nBabyBirds = atoi(argv[1]);
    W = atoi(argv[2]);
    
    // Initialize dynamic array
    wormsEaten = calloc(nBabyBirds, sizeof(int));

    // Initialize semaphores
    sem_init(&dishSem, SHARED, W);
    sem_init(&parentSem, SHARED, 0);
    sem_init(&mutex, SHARED, 1);

    pthread_t parentThread, babyThreads[nBabyBirds];

    // Create threads
    pthread_create(&parentThread, NULL, parentBird, NULL);
    for (int i = 0; i < nBabyBirds; i++) {
        pthread_create(&babyThreads[i], NULL, babyBird, (void*)(intptr_t)i);
    }

    // Wait for completion
    pthread_join(parentThread, NULL);
    for (int i = 0; i < nBabyBirds; i++) pthread_join(babyThreads[i], NULL);

    // Print results
    printf("\n=== Final Results ===\n");
    for (int i = 0; i < nBabyBirds; i++) {
        printf("Baby %d: %d worms\n", i + 1, wormsEaten[i]);
    }

    // Cleanup
    free(wormsEaten);
    sem_destroy(&dishSem);
    sem_destroy(&parentSem);
    sem_destroy(&mutex);

    return 0;
}